# %% [markdown]
# # CodeAlpha Task 3: Car Price Prediction
# **Goal:** predict a used car's price from features such as mileage, engine size, make, type and extras.
#
# **Data:** `car_worth.csv`, 804 used 2005 GM cars (public dataset from the Wesleyan QAC applied-data course; prices follow the Kelley Blue Book).
#
# **Steps:** load, clean, explore, preprocess, compare regression models, evaluate, interpret.

# %%
import numpy as np, pandas as pd
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.feature_selection import f_regression
from sklearn.inspection import permutation_importance
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
sns.set_theme(style="whitegrid")
RANDOM_STATE = 42

# %% [markdown]
# ## 1. Load the data

# %%
df = pd.read_csv("data/car_worth.csv")
print(df.shape)
df.head()

# %%
df.info()

# %% [markdown]
# Columns: **Price** (target), Mileage, Make, Model, Trim, Type, Cylinder, Liter (engine size), Doors, and the 0/1 extras Cruise, Sound, Leather.

# %% [markdown]
# ## 2. Data quality (Module 3: missing values and outliers)

# %%
print("Missing values:\n", df.isnull().sum(), "\n")
print("Duplicate rows:", df.duplicated().sum())
df.describe().round(2)

# %%
def iqr_outliers(s):
    q1, q3 = s.quantile([.25, .75]); iqr = q3 - q1
    return ((s < q1 - 1.5*iqr) | (s > q3 + 1.5*iqr)).sum()

for col in ["Price", "Mileage"]:
    print(f"{col}: {iqr_outliers(df[col])} IQR outliers out of {len(df)}")
fig, ax = plt.subplots(1, 2, figsize=(10, 3))
sns.boxplot(x=df["Price"], ax=ax[0]); sns.boxplot(x=df["Mileage"], ax=ax[1])
plt.tight_layout(); plt.savefig("images/boxplots.png", dpi=120); plt.show()

# %% [markdown]
# There are no missing values. The high-price points are real luxury cars (15 of the 17 price outliers are Cadillacs), not typing errors, so we **keep** them (keep-and-flag rule from Module 3). The model pipeline still includes an imputer, so it also works on new data that has gaps.

# %% [markdown]
# ## 3. Explore

# %%
print(df["Price"].describe().round(0))
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
sns.histplot(df["Price"], kde=True, ax=ax[0]); ax[0].set_title("Price distribution")
order = df.groupby("Make")["Price"].median().sort_values().index
sns.boxplot(data=df, x="Make", y="Price", order=order, ax=ax[1]); ax[1].set_title("Price by make")
plt.tight_layout(); plt.savefig("images/price_eda.png", dpi=120); plt.show()

# %%
num = ["Mileage", "Cylinder", "Liter", "Doors", "Cruise", "Sound", "Leather"]
plt.figure(figsize=(7, 5))
sns.heatmap(df[["Price"] + num].corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation with price"); plt.tight_layout()
plt.savefig("images/correlation.png", dpi=120); plt.show()

# %% [markdown]
# Engine size (Cylinder 0.57, Liter 0.56) and Cruise (0.43) show the strongest positive link with price. Mileage has a weak negative link (-0.14).

# %% [markdown]
# ## 4. Feature selection (filter method: F-test for a regression target)

# %%
f, p = f_regression(df[num], df["Price"])
fs = pd.DataFrame({"F-score": f.round(1), "p-value": p.round(4)}, index=num).sort_values("F-score", ascending=False)
fs

# %% [markdown]
# Features with a high F-score and tiny p-value carry real signal. We keep all of them because the dataset is small and the models handle extra features well.

# %% [markdown]
# ## 5. Features and preprocessing
# * Numeric columns: median imputation, then scaling.
# * Categorical columns (Make, Model, Type): most-frequent imputation, then one-hot encoding.
# * `Trim` is dropped because it is a very detailed label that overlaps with Model and Type.
# * The preprocessing lives in a `Pipeline`, so it is **fitted on training data only** (no data leakage).

# %%
cat = ["Make", "Model", "Type"]
X, y = df[num + cat], df["Price"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=RANDOM_STATE)
print(X_train.shape, X_test.shape)

pre = ColumnTransformer([
    ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num),
    ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                      ("oh", OneHotEncoder(handle_unknown="ignore"))]), cat),
])

# %% [markdown]
# ## 6. Compare models (5-fold cross-validation on training data)

# %%
models = {
    "Linear Regression": LinearRegression(),
    "Ridge": Ridge(alpha=1.0),
    "Random Forest": RandomForestRegressor(n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1),
    "Gradient Boosting": GradientBoostingRegressor(random_state=RANDOM_STATE),
}
cv = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
rows = []
for name, m in models.items():
    pipe = Pipeline([("pre", pre), ("model", m)])
    r2 = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="r2")
    mae = -cross_val_score(pipe, X_train, y_train, cv=cv, scoring="neg_mean_absolute_error")
    rows.append((name, r2.mean(), mae.mean()))
cv_df = pd.DataFrame(rows, columns=["Model", "CV R2", "CV MAE ($)"]).sort_values("CV R2", ascending=False)
cv_df.round(3)

# %% [markdown]
# ## 7. Final evaluation on the unseen test set

# %%
best_name = cv_df.iloc[0]["Model"]
print("Best model by cross-validation:", best_name)
best = Pipeline([("pre", pre), ("model", models[best_name])]).fit(X_train, y_train)
pred = best.predict(X_test)
r2 = r2_score(y_test, pred)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
print(f"Test R2   : {r2:.3f}")
print(f"Test MAE  : ${mae:,.0f}")
print(f"Test RMSE : ${rmse:,.0f}")

# %%
fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
ax[0].scatter(y_test, pred, alpha=.6)
lim = [min(y_test.min(), pred.min()), max(y_test.max(), pred.max())]
ax[0].plot(lim, lim, "r--"); ax[0].set_xlabel("Actual price"); ax[0].set_ylabel("Predicted price")
ax[0].set_title("Actual vs predicted")
ax[1].scatter(pred, y_test - pred, alpha=.6); ax[1].axhline(0, color="r", ls="--")
ax[1].set_xlabel("Predicted price"); ax[1].set_ylabel("Residual"); ax[1].set_title("Residuals")
plt.tight_layout(); plt.savefig("images/predictions.png", dpi=120); plt.show()

# %% [markdown]
# ## 8. What drives the price? (permutation importance)
# Shuffle one original feature at a time and see how much the test score drops.

# %%
pi = permutation_importance(best, X_test, y_test, n_repeats=15, random_state=RANDOM_STATE, scoring="r2")
imp = pd.Series(pi.importances_mean, index=X.columns).sort_values()
imp.plot.barh(color="steelblue"); plt.title("Permutation importance (drop in R2)")
plt.tight_layout(); plt.savefig("images/importance.png", dpi=120); plt.show()
imp.sort_values(ascending=False).round(3)

# %% [markdown]
# ## 9. Predict a new car

# %%
new = pd.DataFrame([{"Mileage": 20000, "Cylinder": 6, "Liter": 3.1, "Doors": 4,
                     "Cruise": 1, "Sound": 1, "Leather": 1,
                     "Make": "Buick", "Model": "Century", "Type": "Sedan"}])
print(f"Estimated price: ${best.predict(new)[0]:,.0f}")

# %% [markdown]
# ## Conclusion
# * The data is clean; high prices are genuine luxury cars, so outliers were kept.
# * Make and engine size (Liter) explain most of the price; Model and Mileage add a little, and the extras (Cruise, Sound, Leather) add almost nothing once those are known.
# * Gradient Boosting, Random Forest and plain Linear Regression all score about the same (R2 around 0.98 in cross-validation), so the simple linear model is already a strong, easy-to-explain choice here.
# * Limits: the data covers only 2005 GM cars, so predictions will not transfer to other brands or years.
