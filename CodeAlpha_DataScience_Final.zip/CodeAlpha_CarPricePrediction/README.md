# CodeAlpha_CarPricePrediction

CodeAlpha Data Science Internship, **Task 3: Car Price Prediction with Machine Learning**.

Predicts a used car's price from mileage, engine size, make, model, type and extras.

## Data
`data/car_worth.csv`: 804 used 2005 GM cars (public dataset from the Wesleyan QAC applied-data course, prices follow the Kelley Blue Book).
Source: https://raw.githubusercontent.com/nazzstat/AppliedData/master/PracticeData/car_worth.csv
Note: this is a public alternative to the dataset linked in the internship brief, which was not accessible when this was built. Replace the CSV and column lists if you must use the official file.

## Files
- `car_price_prediction.ipynb`: full executed notebook
- `car_price_prediction.py`: same code as a plain script (cells marked with `# %%`)
- `images/`: saved charts

## Method
1. Data quality: no missing values or duplicates. 17 IQR price outliers (15 are Cadillacs), kept because they are genuine luxury cars.
2. EDA and correlations; F-test feature scores (Module 3 filter method).
3. Preprocessing in a `Pipeline` (imputation, scaling, one-hot encoding), fitted on training data only.
4. Compared Linear Regression, Ridge, Random Forest and Gradient Boosting with 5-fold cross-validation.
5. Final evaluation on a held-out 20% test set; permutation importance for interpretation.

## Results
| Model | CV R2 | CV MAE ($) |
|---|---|---|
| Gradient Boosting | 0.978 | 1,115 |
| Linear Regression | 0.978 | 1,127 |
| Random Forest | 0.976 | 1,109 |
| Ridge | 0.976 | 1,181 |

Test set (Gradient Boosting): **R2 0.977, MAE about $987, RMSE about $1,355**.
Make and engine size (Liter) drive price most. Models are close, so the simple linear model is also a good, explainable choice.

## Limits
Covers only 2005 GM cars; predictions will not transfer to other brands or years.

## Run
```
pip install -r requirements.txt
jupyter notebook car_price_prediction.ipynb
```
