# CodeAlpha_IrisFlowerClassification

CodeAlpha Data Science Internship, **Task 1: Iris Flower Classification**.

Classifies Iris flowers (setosa, versicolor, virginica) from sepal and petal measurements using scikit-learn.

## Files
- `iris_classification.ipynb`: full executed notebook (EDA, model comparison, evaluation)
- `iris_classification.py`: same code as a plain script (cells marked with `# %%`)
- `data/iris.csv`: dataset exported from `sklearn.datasets.load_iris`
- `images/`: saved charts

## Method
1. Data quality check: no missing values, 4 mild IQR outliers in sepal width (kept, they are real flowers).
2. EDA: pairplot and correlation heatmap. Petal length and width separate the species best (ANOVA F-test).
3. Stratified 80/20 train/test split; scaling inside a `Pipeline` to avoid data leakage.
4. Compared Logistic Regression, KNN, SVM, Decision Tree and Random Forest with 5-fold cross-validation.
5. Evaluated the best model once on the held-out test set.

## Results
| Model | CV accuracy |
|---|---|
| SVM (RBF) | 0.967 |
| Logistic Regression | 0.958 |
| KNN (k=5) | 0.958 |
| Decision Tree | 0.950 |
| Random Forest | 0.950 |

Test accuracy (SVM): **96.7%** (29/30). Only 30 test flowers, so one mistake moves accuracy about 3 points.

## Run
```
pip install -r requirements.txt
jupyter notebook iris_classification.ipynb
```
