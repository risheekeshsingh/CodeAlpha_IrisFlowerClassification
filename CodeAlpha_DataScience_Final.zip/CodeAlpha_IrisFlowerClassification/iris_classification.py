# %% [markdown]
# # CodeAlpha Task 1: Iris Flower Classification
# **Goal:** classify an Iris flower as *setosa*, *versicolor* or *virginica* from four measurements.
#
# **Steps:** load data, explore, check quality, split, compare models, evaluate on unseen test data.

# %%
import numpy as np, pandas as pd
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
sns.set_theme(style="whitegrid")
RANDOM_STATE = 42

# %% [markdown]
# ## 1. Load the data
# Iris ships inside scikit-learn (150 flowers, 3 species, 50 each).

# %%
iris = load_iris(as_frame=True)
df = iris.frame.copy()
df["species"] = df["target"].map(dict(enumerate(iris.target_names)))
df.drop(columns="target").to_csv("data/iris.csv", index=False)
print(df.shape)
df.head()

# %% [markdown]
# ## 2. Data quality check (Module 3: missing values and outliers)

# %%
features = list(iris.feature_names)
print("Missing values per column:\n", df[features].isnull().sum(), "\n")
print("Duplicate rows:", df.duplicated().sum())
print("\nOutliers by the IQR rule (value < Q1-1.5*IQR or > Q3+1.5*IQR):")
for col in features:
    q1, q3 = df[col].quantile([.25, .75]); iqr = q3 - q1
    n = ((df[col] < q1 - 1.5*iqr) | (df[col] > q3 + 1.5*iqr)).sum()
    print(f"  {col:<20} {n}")
df[features].describe().round(2)

# %% [markdown]
# No missing values. A few mild IQR outliers (in sepal width) look like real flowers, not errors, so we **keep** them.

# %% [markdown]
# ## 3. Explore

# %%
print(df["species"].value_counts())
sns.pairplot(df.drop(columns="target"), hue="species", corner=True)
plt.savefig("images/pairplot.png", dpi=120, bbox_inches="tight"); plt.show()

# %%
plt.figure(figsize=(6,4.5))
sns.heatmap(df[features].corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Feature correlation"); plt.tight_layout()
plt.savefig("images/correlation.png", dpi=120); plt.show()

# %% [markdown]
# Petal length and petal width separate the species best, and setosa is clearly distinct.

# %% [markdown]
# ## 4. Feature importance (filter method: ANOVA F-test)

# %%
X, y = df[features], df["species"]
sel = SelectKBest(f_classif, k="all").fit(X, y)
scores = pd.Series(sel.scores_, index=features).sort_values(ascending=False)
print(scores.round(1))
scores.plot.barh(color="steelblue").invert_yaxis()
plt.title("ANOVA F-score per feature"); plt.tight_layout()
plt.savefig("images/feature_scores.png", dpi=120); plt.show()

# %% [markdown]
# ## 5. Train/test split
# 80% train, 20% test, **stratified** so every species keeps the same share. The test set stays untouched until the final evaluation.

# %%
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE)
print(X_train.shape, X_test.shape)

# %% [markdown]
# ## 6. Compare models with 5-fold cross-validation (training data only)
# The scaler sits inside a `Pipeline`, so it is fitted only on each training fold. This avoids data leakage.

# %%
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "KNN (k=5)": KNeighborsClassifier(n_neighbors=5),
    "SVM (RBF)": SVC(),
    "Decision Tree": DecisionTreeClassifier(random_state=RANDOM_STATE),
    "Random Forest": RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE),
}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
rows = []
for name, m in models.items():
    pipe = Pipeline([("scale", StandardScaler()), ("model", m)])
    s = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="accuracy")
    rows.append((name, s.mean(), s.std()))
cv_df = pd.DataFrame(rows, columns=["Model", "CV accuracy", "Std"]).sort_values("CV accuracy", ascending=False)
cv_df.round(4)

# %% [markdown]
# ## 7. Final evaluation on the unseen test set

# %%
best_name = cv_df.iloc[0]["Model"]
print("Best model by cross-validation:", best_name)
best = Pipeline([("scale", StandardScaler()), ("model", models[best_name])]).fit(X_train, y_train)
pred = best.predict(X_test)
print(f"\nTest accuracy: {accuracy_score(y_test, pred):.4f}\n")
print(classification_report(y_test, pred))

# %%
ConfusionMatrixDisplay(confusion_matrix(y_test, pred, labels=iris.target_names),
                       display_labels=iris.target_names).plot(cmap="Blues")
plt.title(f"Confusion matrix: {best_name}"); plt.tight_layout()
plt.savefig("images/confusion_matrix.png", dpi=120); plt.show()

# %% [markdown]
# ## 8. Predict a new flower

# %%
new = pd.DataFrame([[5.1, 3.5, 1.4, 0.2]], columns=features)
print("Prediction for", new.values.tolist()[0], "->", best.predict(new)[0])

# %% [markdown]
# ## Conclusion
# * The dataset is clean (no missing values; one duplicate row, which is harmless).
# * Petal measurements are the strongest predictors.
# * All five models reach about 95-97% cross-validated accuracy; the best one (SVM) is evaluated once on held-out data and scores 96.7% (29 of 30 correct).
# * With only 30 test flowers, one mistake moves accuracy by about 3 points, so treat the test score as approximate.
